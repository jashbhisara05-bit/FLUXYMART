import { useState } from 'react';
import { Package, Search, Truck, CheckCircle, Clock, MapPin } from 'lucide-react';

const trackingSteps = [
  { label: 'Order Placed', icon: Package, completed: true },
  { label: 'Processing', icon: Clock, completed: true },
  { label: 'Shipped', icon: Truck, completed: true },
  { label: 'In Transit', icon: MapPin, completed: true },
  { label: 'Delivered', icon: CheckCircle, completed: false },
];

export default function TrackOrder() {
  const [orderNumber, setOrderNumber] = useState('');
  const [email, setEmail] = useState('');
  const [tracked, setTracked] = useState(false);

  const handleTrack = (e: React.FormEvent) => {
    e.preventDefault();
    if (orderNumber && email) {
      setTracked(true);
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Hero */}
      <section className="bg-gradient-to-br from-indigo-900 via-purple-900 to-slate-900 text-white py-16 sm:py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <Package className="w-12 h-12 text-indigo-300 mx-auto mb-4" />
          <h1 className="text-4xl sm:text-5xl font-bold mb-4">Track Your Order</h1>
          <p className="text-xl text-gray-300 max-w-2xl mx-auto">
            Enter your order number and email to see the latest status
          </p>
        </div>
      </section>

      <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {/* Search Form */}
        <div className="bg-white rounded-xl shadow-sm p-6 sm:p-8 mb-8">
          <form onSubmit={handleTrack} className="space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1.5">
                  Order Number *
                </label>
                <input
                  type="text"
                  required
                  value={orderNumber}
                  onChange={(e) => setOrderNumber(e.target.value)}
                  placeholder="e.g., ORD-12345"
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1.5">
                  Email Address *
                </label>
                <input
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="john@example.com"
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
                />
              </div>
            </div>
            <button
              type="submit"
              className="w-full py-3 bg-indigo-600 text-white rounded-xl font-semibold hover:bg-indigo-700 transition-colors flex items-center justify-center gap-2"
            >
              <Search className="w-4 h-4" />
              Track Order
            </button>
          </form>
        </div>

        {/* Tracking Results */}
        {tracked && (
          <div className="space-y-6">
            {/* Order Info */}
            <div className="bg-white rounded-xl shadow-sm p-6">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <div>
                  <p className="text-sm text-gray-500">Order Number</p>
                  <p className="font-semibold text-gray-900">{orderNumber}</p>
                </div>
                <div>
                  <p className="text-sm text-gray-500">Estimated Delivery</p>
                  <p className="font-semibold text-gray-900">March 15-20, 2026</p>
                </div>
                <div>
                  <p className="text-sm text-gray-500">Status</p>
                  <span className="inline-flex items-center gap-1 px-3 py-1 bg-blue-100 text-blue-700 rounded-full text-sm font-medium">
                    <Truck className="w-3.5 h-3.5" />
                    In Transit
                  </span>
                </div>
              </div>
            </div>

            {/* Tracking Timeline */}
            <div className="bg-white rounded-xl shadow-sm p-6 sm:p-8">
              <h2 className="text-lg font-semibold text-gray-900 mb-8">Tracking Timeline</h2>
              <div className="relative">
                {/* Vertical line */}
                <div className="absolute left-5 top-0 bottom-0 w-0.5 bg-gray-200" />

                <div className="space-y-8">
                  {trackingSteps.map((step, idx) => (
                    <div key={step.label} className="relative flex items-start gap-6">
                      <div
                        className={`relative z-10 w-10 h-10 rounded-full flex items-center justify-center ${
                          step.completed
                            ? 'bg-indigo-600 text-white'
                            : 'bg-gray-100 text-gray-400'
                        }`}
                      >
                        <step.icon className="w-5 h-5" />
                      </div>
                      <div className="pt-1.5">
                        <p
                          className={`font-semibold ${
                            step.completed ? 'text-gray-900' : 'text-gray-400'
                          }`}
                        >
                          {step.label}
                        </p>
                        <p className="text-sm text-gray-500 mt-0.5">
                          {step.completed
                            ? idx === 0
                              ? 'Feb 28, 2026 - 10:30 AM'
                              : idx === 1
                              ? 'Mar 1, 2026 - 2:15 PM'
                              : idx === 2
                              ? 'Mar 3, 2026 - 9:00 AM'
                              : 'Mar 5, 2026 - 11:45 AM'
                            : 'Pending'}
                        </p>
                        {step.completed && (
                          <p className="text-xs text-gray-400 mt-0.5">
                            {idx === 0 && 'Your order has been confirmed'}
                            {idx === 1 && 'Your items are being prepared'}
                            {idx === 2 && 'Package has been handed to carrier'}
                            {idx === 3 && 'Package is traveling to your address'}
                          </p>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* Delivery Address */}
            <div className="bg-white rounded-xl shadow-sm p-6">
              <h3 className="font-semibold text-gray-900 mb-2">Delivery Address</h3>
              <p className="text-gray-600 text-sm">
                123 Main Street<br />
                Apt 4B<br />
                New York, NY 10001<br />
                United States
              </p>
            </div>

            {/* Need help */}
            <div className="bg-indigo-50 rounded-xl p-6 text-center">
              <p className="text-gray-900 font-medium mb-2">Need help with your order?</p>
              <p className="text-gray-600 text-sm">
                Contact us at{' '}
                <a href="mailto:support@fluxymart.com" className="text-indigo-600 font-medium">
support@fluxymart.com
                </a>{' '}
                or via{' '}
                <a href="https://wa.me/18001234567" target="_blank" rel="noopener noreferrer" className="text-indigo-600 font-medium">
                  WhatsApp
                </a>
              </p>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
