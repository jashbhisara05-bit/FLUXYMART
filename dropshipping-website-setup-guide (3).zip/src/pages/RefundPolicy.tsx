import { RefreshCw } from 'lucide-react';

export default function RefundPolicy() {
  return (
    <div className="min-h-screen bg-gray-50">
      <section className="bg-gradient-to-br from-indigo-900 via-purple-900 to-slate-900 text-white py-16 sm:py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <RefreshCw className="w-12 h-12 text-indigo-300 mx-auto mb-4" />
          <h1 className="text-4xl sm:text-5xl font-bold mb-4">Refund & Return Policy</h1>
          <p className="text-xl text-gray-300">Last updated: January 1, 2026</p>
        </div>
      </section>

      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="bg-white rounded-xl shadow-sm p-6 sm:p-8">
          <div className="bg-indigo-50 rounded-xl p-4 mb-8">
            <p className="text-sm text-indigo-800 font-medium">
              💯 Our Promise: If you're not satisfied with your purchase, we'll make it right.
            </p>
          </div>

          <h2 className="text-2xl font-bold text-gray-900 mb-4">Return Window</h2>
          <p className="text-gray-600 leading-relaxed mb-6">
            We accept returns within <strong>30 calendar days</strong> from the date of delivery. To be eligible for a return, items must be unused, in their original condition, and in the original packaging.
          </p>

          <h2 className="text-2xl font-bold text-gray-900 mb-4 mt-8">Conditions for Returns</h2>
          <p className="text-gray-600 leading-relaxed mb-4">To qualify for a return, the following conditions must be met:</p>
          <ul className="list-disc pl-6 text-gray-600 space-y-2 mb-6">
            <li>Item must be unused and in the same condition as received</li>
            <li>Item must be in its original packaging with all tags and accessories</li>
            <li>Proof of purchase (order number or receipt) is required</li>
            <li>Return request must be initiated within 30 days of delivery</li>
            <li>Items must be returned within 14 days of receiving the return authorization</li>
          </ul>

          <h2 className="text-2xl font-bold text-gray-900 mb-4 mt-8">Non-Returnable Items</h2>
          <p className="text-gray-600 leading-relaxed mb-4">The following items cannot be returned:</p>
          <ul className="list-disc pl-6 text-gray-600 space-y-2 mb-6">
            <li>Gift cards</li>
            <li>Downloadable software products</li>
            <li>Personal care items (earrings, undergarments) due to hygiene reasons</li>
            <li>Items marked as "Final Sale" or "Non-Returnable"</li>
            <li>Items returned without original packaging or in used condition</li>
          </ul>

          <h2 className="text-2xl font-bold text-gray-900 mb-4 mt-8">Return Process</h2>
          <ol className="list-decimal pl-6 text-gray-600 space-y-3 mb-6">
            <li>Contact us at <a href="mailto:support@fluxymart.com" className="text-indigo-600 hover:underline">support@fluxymart.com</a> with your order number and reason for return</li>
            <li>We will provide you with a Return Authorization (RA) number and return address</li>
            <li>Pack the item securely in its original packaging including all accessories</li>
            <li>Ship the item to the provided address with a trackable shipping method</li>
            <li>Once we receive and inspect the item, we will process your refund within 5-7 business days</li>
          </ol>

          <h2 className="text-2xl font-bold text-gray-900 mb-4 mt-8">Refund Timeline</h2>
          <p className="text-gray-600 leading-relaxed mb-4">After we receive your return:</p>
          <ul className="list-disc pl-6 text-gray-600 space-y-2 mb-6">
            <li>Inspection: 1-2 business days</li>
            <li>Refund processing: 5-7 business days</li>
            <li>Credit to your account: 5-10 business days (depending on your bank/payment provider)</li>
            <li>Total estimated time from drop-off to refund: 10-15 business days</li>
          </ul>

          <h2 className="text-2xl font-bold text-gray-900 mb-4 mt-8">Restocking Fees</h2>
          <p className="text-gray-600 leading-relaxed mb-6">
            We do <strong>not</strong> charge restocking fees for standard returns. However, if an item is returned in a condition that significantly reduces its resale value, a partial refund (up to 20%) may be applied after inspection.
          </p>

          <h2 className="text-2xl font-bold text-gray-900 mb-4 mt-8">Return Shipping Costs</h2>
          <ul className="list-disc pl-6 text-gray-600 space-y-2 mb-6">
            <li><strong>Customer error</strong> (changed mind, wrong size, etc.): You are responsible for return shipping costs</li>
            <li><strong>Our error</strong> (wrong item shipped, defective, damaged): We will provide a prepaid return label</li>
            <li>Original shipping charges are non-refundable unless the return is due to our error</li>
          </ul>

          <h2 className="text-2xl font-bold text-gray-900 mb-4 mt-8">Exchanges</h2>
          <p className="text-gray-600 leading-relaxed mb-6">
            We offer exchanges for a different size, color, or product of equal value. Contact us within 30 days of delivery to initiate an exchange. Exchanges are processed once the original item is returned and inspected.
          </p>

          <h2 className="text-2xl font-bold text-gray-900 mb-4 mt-8">Damaged or Incorrect Items</h2>
          <p className="text-gray-600 leading-relaxed mb-6">
            If you receive a damaged, defective, or incorrect item, please contact us within 48 hours of delivery with photos of the issue. We will arrange a replacement or full refund, including all shipping costs.
          </p>

          <h2 className="text-2xl font-bold text-gray-900 mb-4 mt-8">Contact</h2>
          <p className="text-gray-600 leading-relaxed mb-6">
            For any return-related questions, please contact us at{' '}
            <a href="mailto:support@fluxymart.com" className="text-indigo-600 hover:underline">support@fluxymart.com</a>.
          </p>
        </div>
      </div>
    </div>
  );
}
