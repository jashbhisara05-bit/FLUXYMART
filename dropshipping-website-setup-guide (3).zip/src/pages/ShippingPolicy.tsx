import { Truck } from 'lucide-react';

export default function ShippingPolicy() {
  return (
    <div className="min-h-screen bg-gray-50">
      <section className="bg-gradient-to-br from-indigo-900 via-purple-900 to-slate-900 text-white py-16 sm:py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <Truck className="w-12 h-12 text-indigo-300 mx-auto mb-4" />
          <h1 className="text-4xl sm:text-5xl font-bold mb-4">Shipping Policy</h1>
          <p className="text-xl text-gray-300">Last updated: January 1, 2026</p>
        </div>
      </section>

      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="bg-white rounded-xl shadow-sm p-6 sm:p-8">
          <h2 className="text-2xl font-bold text-gray-900 mb-4">Processing Time</h2>
          <p className="text-gray-600 leading-relaxed mb-6">
            Orders are processed within 1-3 business days (excluding weekends and holidays) after receiving your order confirmation email. You will receive another notification when your order has shipped.
          </p>

          <h2 className="text-2xl font-bold text-gray-900 mb-4 mt-8">Delivery Rates & Estimates</h2>
          <div className="overflow-x-auto mb-6">
            <table className="w-full text-sm">
              <thead>
                <tr className="bg-gray-50">
                  <th className="text-left px-4 py-3 font-semibold text-gray-900">Delivery Method</th>
                  <th className="text-left px-4 py-3 font-semibold text-gray-900">Estimated Delivery</th>
                  <th className="text-left px-4 py-3 font-semibold text-gray-900">Cost</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-100">
                <tr>
                  <td className="px-4 py-3 text-gray-700">Standard Delivery</td>
                  <td className="px-4 py-3 text-gray-700">5-10 business days</td>
                  <td className="px-4 py-3 text-green-600 font-medium">FREE</td>
                </tr>
                <tr>
                  <td className="px-4 py-3 text-gray-700">Express Delivery</td>
                  <td className="px-4 py-3 text-gray-700">2-4 business days</td>
                  <td className="px-4 py-3 text-green-600 font-medium">FREE</td>
                </tr>
                <tr>
                  <td className="px-4 py-3 text-gray-700">International Standard</td>
                  <td className="px-4 py-3 text-gray-700">10-20 business days</td>
                  <td className="px-4 py-3 text-green-600 font-medium">FREE</td>
                </tr>
                <tr>
                  <td className="px-4 py-3 text-gray-700">International Express</td>
                  <td className="px-4 py-3 text-gray-700">5-10 business days</td>
                  <td className="px-4 py-3 text-green-600 font-medium">FREE</td>
                </tr>
              </tbody>
            </table>
          </div>

          <h2 className="text-2xl font-bold text-gray-900 mb-4 mt-8">Shipping Carriers</h2>
          <p className="text-gray-600 leading-relaxed mb-6">
            We work with reliable carriers including USPS, FedEx, DHL, and UPS. Depending on your location and the shipping method selected, your package may be handled by one or more of these carriers.
          </p>

          <h2 className="text-2xl font-bold text-gray-900 mb-4 mt-8">International Shipping</h2>
          <p className="text-gray-600 leading-relaxed mb-4">We ship to over 30 countries worldwide. Please note:</p>
          <ul className="list-disc pl-6 text-gray-600 space-y-2 mb-6">
            <li>International delivery times are estimates and may be affected by customs processing</li>
            <li>You are responsible for any customs duties, taxes, or import fees</li>
            <li>Customs policies vary widely by country — please check with your local customs office</li>
            <li>We are not responsible for delays caused by customs</li>
            <li>Some items may be restricted in certain countries</li>
          </ul>

          <h2 className="text-2xl font-bold text-gray-900 mb-4 mt-8">Order Tracking</h2>
          <p className="text-gray-600 leading-relaxed mb-6">
            Once your order ships, you will receive a shipping confirmation email with a tracking number. You can track your order on our Track Order page or directly on the carrier's website. Please allow 24-48 hours for tracking information to update.
          </p>

          <h2 className="text-2xl font-bold text-gray-900 mb-4 mt-8">Shipping Address</h2>
          <p className="text-gray-600 leading-relaxed mb-6">
            Please ensure your shipping address is correct. We are not responsible for orders delivered to incorrect addresses provided by the customer. If you need to change your shipping address, please contact us within 2 hours of placing your order.
          </p>

          <h2 className="text-2xl font-bold text-gray-900 mb-4 mt-8">Lost or Damaged Packages</h2>
          <p className="text-gray-600 leading-relaxed mb-6">
            If your package is lost or arrives damaged, please contact us within 48 hours of the expected delivery date. We will open an investigation with the carrier and work to resolve the issue as quickly as possible. For damaged items, please include photos of the damage in your email.
          </p>

          <h2 className="text-2xl font-bold text-gray-900 mb-4 mt-8">Contact</h2>
          <p className="text-gray-600 leading-relaxed mb-6">
            For any shipping-related questions, please contact us at{' '}
            <a href="mailto:support@fluxymart.com" className="text-indigo-600 hover:underline">support@fluxymart.com</a>.
          </p>
        </div>
      </div>
    </div>
  );
}
