import { Shield, Heart, Globe, Award, Users, TrendingUp } from 'lucide-react';
import { Link } from 'react-router-dom';

const stats = [
  { value: '50K+', label: 'Happy Customers' },
  { value: '10K+', label: 'Products Delivered' },
  { value: '4.8', label: 'Average Rating' },
  { value: '30+', label: 'Countries Served' },
];

const values = [
  {
    icon: Shield,
    title: 'Trust & Transparency',
    desc: 'We believe in honest business practices. No hidden fees, no fake reviews — just quality products and real customer experiences.',
  },
  {
    icon: Heart,
    title: 'Customer First',
    desc: 'Every decision we make starts with our customers. From product selection to shipping, your satisfaction drives everything we do.',
  },
  {
    icon: Globe,
    title: 'Global Access',
    desc: 'We connect you with premium products from around the world. Our network of trusted suppliers ensures you get the best deals.',
  },
  {
    icon: Award,
    title: 'Quality Guaranteed',
    desc: 'Every product in our catalog is carefully vetted for quality. We only partner with suppliers who meet our strict standards.',
  },
];

export default function About() {
  return (
    <div>
      {/* Hero */}
      <section className="bg-gradient-to-br from-indigo-900 via-purple-900 to-slate-900 text-white py-20 sm:py-28">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-4xl sm:text-5xl lg:text-6xl font-bold mb-6">
            About FluxyMart.com
          </h1>
          <p className="text-xl text-gray-300 max-w-3xl mx-auto leading-relaxed">
            We're on a mission to make quality products accessible to everyone, everywhere. 
            No middlemen, no markup — just great products at fair prices.
          </p>
        </div>
      </section>

      {/* Story */}
      <section className="py-16 sm:py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-3xl sm:text-4xl font-bold text-gray-900 mb-6">Our Story</h2>
              <div className="space-y-4 text-gray-600 leading-relaxed">
                <p>
                  FluxyMart.com was born from a simple idea: quality products shouldn't cost a fortune. 
                  Founded in 2024, we set out to build an online marketplace that connects customers 
                  directly with top manufacturers and trusted suppliers around the world.
                </p>
                <p>
                  We saw how traditional retail added layers of markup, making everyday essentials 
                  and luxury items unnecessarily expensive. By leveraging a global network of 
                  vetted suppliers and efficient dropshipping, we pass those savings directly to you.
                </p>
                <p>
                  Today, we serve over 50,000 happy customers across 30+ countries. Our curated 
                  catalog features everything from smart home gadgets to beauty essentials, each 
                  product hand-picked for quality and value.
                </p>
              </div>
            </div>
            <div className="relative">
              <img
                src="https://images.unsplash.com/photo-1556742049-0cfed4f6a45d?w=600&q=80"
                alt="Our team at work"
                className="rounded-2xl shadow-xl"
              />
              <div className="absolute -bottom-6 -left-6 bg-indigo-600 text-white p-6 rounded-2xl shadow-xl hidden sm:block">
                <Users className="w-8 h-8 mb-2" />
                <p className="font-bold text-2xl">50K+</p>
                <p className="text-indigo-200 text-sm">Happy Customers</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Stats */}
      <section className="py-16 bg-gradient-to-br from-indigo-50 to-purple-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            {stats.map((stat) => (
              <div key={stat.label} className="text-center">
                <p className="text-4xl sm:text-5xl font-bold bg-gradient-to-r from-indigo-600 to-purple-600 bg-clip-text text-transparent">
                  {stat.value}
                </p>
                <p className="text-gray-600 mt-2">{stat.label}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Values */}
      <section className="py-16 sm:py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl sm:text-4xl font-bold text-gray-900 mb-4">Our Values</h2>
            <p className="text-gray-600 max-w-2xl mx-auto">
              The principles that guide everything we do
            </p>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {values.map((value) => (
              <div key={value.title} className="bg-white rounded-xl p-6 shadow-sm hover:shadow-md transition-shadow">
                <div className="w-12 h-12 bg-indigo-100 rounded-xl flex items-center justify-center mb-4">
                  <value.icon className="w-6 h-6 text-indigo-600" />
                </div>
                <h3 className="font-semibold text-gray-900 mb-2">{value.title}</h3>
                <p className="text-sm text-gray-600 leading-relaxed">{value.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Mission */}
      <section className="py-16 sm:py-20 bg-gray-900 text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <TrendingUp className="w-12 h-12 text-indigo-400 mx-auto mb-6" />
          <h2 className="text-3xl sm:text-4xl font-bold mb-6">Our Mission</h2>
          <p className="text-xl text-gray-300 max-w-3xl mx-auto mb-8">
            To democratize access to quality products by building the most 
            transparent, customer-focused dropshipping platform in the world.
          </p>
          <Link
            to="/shop"
            className="inline-flex items-center gap-2 px-8 py-4 bg-white text-indigo-900 font-semibold rounded-xl hover:bg-gray-100 transition-all"
          >
            Shop With Us
          </Link>
        </div>
      </section>
    </div>
  );
}
