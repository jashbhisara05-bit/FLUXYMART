import { FileText } from 'lucide-react';

export default function TermsConditions() {
  return (
    <div className="min-h-screen bg-gray-50">
      <section className="bg-gradient-to-br from-indigo-900 via-purple-900 to-slate-900 text-white py-16 sm:py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <FileText className="w-12 h-12 text-indigo-300 mx-auto mb-4" />
          <h1 className="text-4xl sm:text-5xl font-bold mb-4">Terms & Conditions</h1>
          <p className="text-xl text-gray-300">Last updated: January 1, 2026</p>
        </div>
      </section>

      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="bg-white rounded-xl shadow-sm p-6 sm:p-8 prose prose-gray max-w-none">
          <h2 className="text-2xl font-bold text-gray-900 mb-4">Acceptance of Terms</h2>
          <p className="text-gray-600 leading-relaxed mb-6">
            By accessing or using FluxyMart.com ("the Website"), you agree to be bound by these Terms & Conditions. If you do not agree with any part of these terms, you may not use our services.
          </p>

          <h2 className="text-2xl font-bold text-gray-900 mb-4 mt-8">Account Registration</h2>
          <p className="text-gray-600 leading-relaxed mb-4">When you create an account on our service, you agree to:</p>
          <ul className="list-disc pl-6 text-gray-600 space-y-2 mb-6">
            <li>Provide accurate, current, and complete information</li>
            <li>Maintain and update your account information promptly</li>
            <li>Keep your password confidential and secure</li>
            <li>Notify us immediately of any unauthorized use of your account</li>
            <li>Be responsible for all activities that occur under your account</li>
          </ul>

          <h2 className="text-2xl font-bold text-gray-900 mb-4 mt-8">Product Information & Pricing</h2>
          <p className="text-gray-600 leading-relaxed mb-4">
            We strive to display accurate product information, including descriptions, images, and pricing. However:
          </p>
          <ul className="list-disc pl-6 text-gray-600 space-y-2 mb-6">
            <li>Product images are for illustration purposes and may vary slightly</li>
            <li>Colors may appear differently depending on your screen settings</li>
            <li>Prices are subject to change without notice</li>
            <li>We reserve the right to correct any pricing errors</li>
            <li>We may modify or discontinue products at any time</li>
          </ul>

          <h2 className="text-2xl font-bold text-gray-900 mb-4 mt-8">Orders & Payment</h2>
          <p className="text-gray-600 leading-relaxed mb-6">
            When you place an order through our Website, you agree to provide current, complete, and accurate purchase and account information. We reserve the right to refuse or cancel any order for reasons including but not limited to: product availability, errors in product or pricing information, or suspected fraud.
          </p>
          <p className="text-gray-600 leading-relaxed mb-6">
            All payments are processed securely through our third-party payment processors (Stripe, PayPal). By providing payment information, you represent that you are authorized to use the designated payment method.
          </p>

          <h2 className="text-2xl font-bold text-gray-900 mb-4 mt-8">Shipping & Delivery</h2>
          <p className="text-gray-600 leading-relaxed mb-6">
            Shipping times are estimates and not guaranteed. We are not responsible for delays caused by customs, carriers, or events beyond our control. Risk of loss and title for items purchased pass to you upon delivery to the carrier.
          </p>

          <h2 className="text-2xl font-bold text-gray-900 mb-4 mt-8">Returns & Refunds</h2>
          <p className="text-gray-600 leading-relaxed mb-6">
            Our return policy is outlined in our separate Refund & Return Policy. All returns must comply with the terms set forth in that policy.
          </p>

          <h2 className="text-2xl font-bold text-gray-900 mb-4 mt-8">Intellectual Property</h2>
          <p className="text-gray-600 leading-relaxed mb-6">
            The Service and its original content, features, and functionality are and will remain the exclusive property of FluxyMart.com and its licensors. Our trademarks and trade dress may not be used in connection with any product or service without our prior written consent.
          </p>

          <h2 className="text-2xl font-bold text-gray-900 mb-4 mt-8">Limitation of Liability</h2>
          <p className="text-gray-600 leading-relaxed mb-6">
            In no event shall FluxyMart.com, nor its directors, employees, partners, agents, suppliers, or affiliates, be liable for any indirect, incidental, special, consequential or punitive damages, including without limitation, loss of profits, data, use, goodwill, or other intangible losses, resulting from your access to or use of or inability to access or use the Service.
          </p>

          <h2 className="text-2xl font-bold text-gray-900 mb-4 mt-8">Prohibited Uses</h2>
          <p className="text-gray-600 leading-relaxed mb-4">You agree not to use the Service for any unlawful purpose or in violation of these terms. Prohibited activities include:</p>
          <ul className="list-disc pl-6 text-gray-600 space-y-2 mb-6">
            <li>Using the Service for any fraudulent or illegal purpose</li>
            <li>Attempting to gain unauthorized access to our systems</li>
            <li>Interfering with or disrupting the Service</li>
            <li>Submitting false or misleading information</li>
            <li>Reselling products purchased from our store</li>
          </ul>

          <h2 className="text-2xl font-bold text-gray-900 mb-4 mt-8">Changes to Terms</h2>
          <p className="text-gray-600 leading-relaxed mb-6">
            We reserve the right to modify or replace these Terms at any time. Changes will be effective immediately upon posting. Your continued use of the Service after any changes constitutes acceptance of the new terms.
          </p>

          <h2 className="text-2xl font-bold text-gray-900 mb-4 mt-8">Contact Information</h2>
          <p className="text-gray-600 leading-relaxed mb-6">
            For questions about these Terms & Conditions, please contact us at{' '}
            <a href="mailto:support@fluxymart.com" className="text-indigo-600 hover:underline">support@fluxymart.com</a>.
          </p>
        </div>
      </div>
    </div>
  );
}
