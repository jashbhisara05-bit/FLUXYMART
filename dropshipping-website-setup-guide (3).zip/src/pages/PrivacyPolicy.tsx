import { Shield } from 'lucide-react';

export default function PrivacyPolicy() {
  return (
    <div className="min-h-screen bg-gray-50">
      <section className="bg-gradient-to-br from-indigo-900 via-purple-900 to-slate-900 text-white py-16 sm:py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <Shield className="w-12 h-12 text-indigo-300 mx-auto mb-4" />
          <h1 className="text-4xl sm:text-5xl font-bold mb-4">Privacy Policy</h1>
          <p className="text-xl text-gray-300">Last updated: January 1, 2026</p>
        </div>
      </section>

      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="bg-white rounded-xl shadow-sm p-6 sm:p-8 prose prose-gray max-w-none">
          <h2 className="text-2xl font-bold text-gray-900 mb-4">Introduction</h2>
          <p className="text-gray-600 leading-relaxed mb-6">
            FluxyMart.com ("we," "our," or "us") is committed to protecting your privacy. This Privacy Policy explains how we collect, use, disclose, and safeguard your information when you visit our website or make a purchase.
          </p>

          <h2 className="text-2xl font-bold text-gray-900 mb-4 mt-8">Information We Collect</h2>
          
          <h3 className="text-xl font-semibold text-gray-900 mb-3">Personal Data</h3>
          <p className="text-gray-600 leading-relaxed mb-4">
            While using our Service, we may ask you to provide us with certain personally identifiable information that can be used to contact or identify you. This includes:
          </p>
          <ul className="list-disc pl-6 text-gray-600 space-y-2 mb-6">
            <li>First and last name</li>
            <li>Email address</li>
            <li>Phone number</li>
            <li>Shipping and billing address</li>
            <li>Payment information (processed securely by Stripe/PayPal)</li>
          </ul>

          <h3 className="text-xl font-semibold text-gray-900 mb-3">Usage Data</h3>
          <p className="text-gray-600 leading-relaxed mb-6">
            We automatically collect certain information when you visit our website, including your IP address, browser type, operating system, referring URLs, and browsing behavior. This helps us improve our services and user experience.
          </p>

          <h3 className="text-xl font-semibold text-gray-900 mb-3">Cookies and Tracking Technologies</h3>
          <p className="text-gray-600 leading-relaxed mb-6">
            We use cookies, web beacons, and similar tracking technologies to track activity on our Service and hold certain information. Cookies are files with a small amount of data that may include an anonymous unique identifier. You can instruct your browser to refuse all cookies or to indicate when a cookie is being sent.
          </p>

          <h2 className="text-2xl font-bold text-gray-900 mb-4 mt-8">How We Use Your Information</h2>
          <p className="text-gray-600 leading-relaxed mb-4">We use the collected data for various purposes:</p>
          <ul className="list-disc pl-6 text-gray-600 space-y-2 mb-6">
            <li>To process and fulfill your orders</li>
            <li>To send you order confirmations and tracking updates</li>
            <li>To communicate with you about your account or transactions</li>
            <li>To provide customer support</li>
            <li>To send marketing communications (with your consent)</li>
            <li>To improve our website and product offerings</li>
            <li>To detect, prevent, and address technical issues and fraud</li>
          </ul>

          <h2 className="text-2xl font-bold text-gray-900 mb-4 mt-8">Third-Party Services</h2>
          <p className="text-gray-600 leading-relaxed mb-6">
            We may employ third-party companies and individuals to facilitate our Service ("Service Providers"), provide the Service on our behalf, perform Service-related services, or assist us in analyzing how our Service is used. These third parties have access to your Personal Data only to perform these tasks on our behalf and are obligated not to disclose or use it for any other purpose.
          </p>
          <p className="text-gray-600 leading-relaxed mb-6">
            Our payment processors (Stripe, PayPal) handle your payment information securely and are PCI-DSS compliant. We never store full credit card numbers on our servers.
          </p>

          <h2 className="text-2xl font-bold text-gray-900 mb-4 mt-8">Data Retention</h2>
          <p className="text-gray-600 leading-relaxed mb-6">
            We will retain your Personal Data only for as long as is necessary for the purposes set out in this Privacy Policy. We will retain and use your information to the extent necessary to comply with our legal obligations, resolve disputes, and enforce our policies.
          </p>

          <h2 className="text-2xl font-bold text-gray-900 mb-4 mt-8">Your Rights</h2>
          <p className="text-gray-600 leading-relaxed mb-4">Depending on your location, you may have the following rights regarding your personal data:</p>
          <ul className="list-disc pl-6 text-gray-600 space-y-2 mb-6">
            <li>The right to access your personal data</li>
            <li>The right to rectify inaccurate personal data</li>
            <li>The right to delete your personal data</li>
            <li>The right to restrict processing of your personal data</li>
            <li>The right to data portability</li>
            <li>The right to object to processing of your personal data</li>
            <li>The right to withdraw consent at any time</li>
          </ul>

          <h2 className="text-2xl font-bold text-gray-900 mb-4 mt-8">Security</h2>
          <p className="text-gray-600 leading-relaxed mb-6">
            The security of your data is important to us. We implement a variety of security measures including SSL/TLS encryption, secure servers, and regular security audits. However, no method of transmission over the Internet is 100% secure.
          </p>

          <h2 className="text-2xl font-bold text-gray-900 mb-4 mt-8">Contact Us</h2>
          <p className="text-gray-600 leading-relaxed mb-6">
            If you have any questions about this Privacy Policy, please contact us at{' '}
            <a href="mailto:support@fluxymart.com" className="text-indigo-600 hover:underline">support@fluxymart.com</a>.
          </p>
        </div>
      </div>
    </div>
  );
}
