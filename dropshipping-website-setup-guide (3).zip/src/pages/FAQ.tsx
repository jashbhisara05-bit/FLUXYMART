import { useState } from 'react';
import { ChevronDown, Search } from 'lucide-react';
import { Link } from 'react-router-dom';

const faqData = [
  {
    category: 'Shipping & Delivery',
    questions: [
      {
        q: 'What are your shipping times?',
        a: 'We offer worldwide shipping with estimated delivery times of 10-15 business days. Please note that these are estimates and actual delivery times may vary depending on your location, customs clearance, and other factors beyond our control.',
      },
      {
        q: 'How much does shipping cost?',
        a: 'We offer completely free delivery on all orders — no minimums, no hidden charges. International delivery is also free for all orders.',
      },
      {
        q: 'Do you ship internationally?',
        a: 'Yes! We ship to over 30 countries worldwide. International orders typically take 12-20 business days. Please note that you may be responsible for any customs duties or taxes in your country.',
      },
      {
        q: 'How can I track my order?',
        a: 'Once your order ships, you\'ll receive a confirmation email with a tracking number. You can track your order anytime on our Track Order page.',
      },
      {
        q: 'What shipping carriers do you use?',
        a: 'We work with major carriers including USPS, FedEx, DHL, and local postal services depending on your location. The carrier will be specified in your shipping confirmation.',
      },
    ],
  },
  {
    category: 'Orders & Tracking',
    questions: [
      {
        q: 'How do I track my order?',
        a: 'Visit our Track Order page and enter your order number and email address. You can also track directly using the tracking number sent to your email.',
      },
      {
        q: 'Can I change or cancel my order?',
        a: 'Orders can be modified or cancelled within 2 hours of placement. After that, the order enters processing and cannot be changed. Contact us immediately if you need to make changes.',
      },
      {
        q: 'What if my order arrives damaged?',
        a: 'We\'re sorry to hear that! Please contact us within 48 hours of delivery with photos of the damage. We\'ll arrange a replacement or full refund immediately.',
      },
      {
        q: 'My tracking hasn\'t updated in days. What should I do?',
        a: 'Tracking updates can sometimes lag, especially during customs processing. If tracking hasn\'t updated for 7+ business days, contact us and we\'ll investigate with the carrier.',
      },
    ],
  },
  {
    category: 'Returns & Refunds',
    questions: [
      {
        q: 'What is your return policy?',
        a: 'We offer a 30-day return policy from the date of delivery. Items must be unused and in their original packaging. See our full Refund & Return Policy for details.',
      },
      {
        q: 'How do I initiate a return?',
        a: 'Contact us at support@fluxymart.com with your order number and reason for return. We\'ll provide a return address and instructions within 24 hours.',
      },
      {
        q: 'How long do refunds take?',
        a: 'Once we receive your return, refunds are processed within 5-7 business days. The refund will appear on your original payment method within 5-10 business days depending on your bank.',
      },
      {
        q: 'Are there any restocking fees?',
        a: 'We do not charge restocking fees for standard returns. However, return shipping costs are the responsibility of the customer unless the item arrived damaged or incorrect.',
      },
      {
        q: 'Can I exchange an item?',
        a: 'Yes! Contact us within 30 days of delivery and we\'ll help you exchange for a different size, color, or product. Exchanges are processed once the original item is returned.',
      },
    ],
  },
  {
    category: 'Payment & Pricing',
    questions: [
      {
        q: 'What payment methods do you accept?',
        a: 'We accept Visa, Mastercard, American Express, PayPal, Apple Pay, Google Pay, and Shop Pay. All payments are processed securely through encrypted connections.',
      },
      {
        q: 'Is it safe to use my credit card?',
        a: 'Absolutely. We use industry-standard SSL encryption and PCI-compliant payment processors (Stripe and PayPal). Your payment information is never stored on our servers.',
      },
      {
        q: 'Do you offer discounts or promo codes?',
        a: 'Yes! New subscribers get 10% off their first order. We also run seasonal sales and offer free delivery on all orders. Sign up for our newsletter to stay updated.',
      },
      {
        q: 'Will I be charged customs fees?',
        a: 'International orders may be subject to customs duties, import taxes, and brokerage fees levied by your country. These fees are the responsibility of the customer and vary by country.',
      },
    ],
  },
  {
    category: 'Sizing & Product Info',
    questions: [
      {
        q: 'How do I find the right size?',
        a: 'Each product page includes a size guide. If you\'re unsure, check the product description for measurements or contact us and we\'ll help you find the perfect fit.',
      },
      {
        q: 'Are the products authentic?',
        a: 'We source our products directly from verified manufacturers and authorized distributors. Every product in our catalog is carefully vetted for quality and authenticity.',
      },
      {
        q: 'Do you have product warranties?',
        a: 'All our products come with a minimum 30-day satisfaction guarantee. Many electronics and gadgets include manufacturer warranties. Check individual product pages for details.',
      },
    ],
  },
];

export default function FAQ() {
  const [openItems, setOpenItems] = useState<Record<string, boolean>>({});
  const [searchQuery, setSearchQuery] = useState('');

  const toggleItem = (key: string) => {
    setOpenItems(prev => ({ ...prev, [key]: !prev[key] }));
  };

  const filteredFaqs = faqData.map(category => ({
    ...category,
    questions: category.questions.filter(
      q =>
        q.q.toLowerCase().includes(searchQuery.toLowerCase()) ||
        q.a.toLowerCase().includes(searchQuery.toLowerCase())
    ),
  })).filter(c => c.questions.length > 0);

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Hero */}
      <section className="bg-gradient-to-br from-indigo-900 via-purple-900 to-slate-900 text-white py-16 sm:py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-4xl sm:text-5xl font-bold mb-4">Frequently Asked Questions</h1>
          <p className="text-xl text-gray-300 max-w-2xl mx-auto">
            Everything you need to know about shopping with us
          </p>
        </div>
      </section>

      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {/* Search */}
        <div className="relative mb-8">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
          <input
            type="text"
            placeholder="Search FAQs..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-12 pr-4 py-3.5 bg-white border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent shadow-sm"
          />
        </div>

        {/* FAQ Categories */}
        <div className="space-y-8">
          {filteredFaqs.map((category) => (
            <div key={category.category} className="bg-white rounded-xl shadow-sm overflow-hidden">
              <div className="px-6 py-4 bg-gradient-to-r from-indigo-50 to-purple-50 border-b border-gray-100">
                <h2 className="text-lg font-semibold text-gray-900">{category.category}</h2>
              </div>
              <div className="divide-y divide-gray-100">
                {category.questions.map((item, idx) => {
                  const key = `${category.category}-${idx}`;
                  const isOpen = openItems[key];
                  return (
                    <div key={key}>
                      <button
                        onClick={() => toggleItem(key)}
                        className="w-full flex items-center justify-between px-6 py-4 text-left hover:bg-gray-50 transition-colors"
                      >
                        <span className="font-medium text-gray-900 pr-8">{item.q}</span>
                        <ChevronDown
                          className={`w-5 h-5 text-gray-400 flex-shrink-0 transition-transform ${
                            isOpen ? 'rotate-180' : ''
                          }`}
                        />
                      </button>
                      {isOpen && (
                        <div className="px-6 pb-4">
                          <p className="text-gray-600 leading-relaxed">{item.a}</p>
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>
          ))}
        </div>

        {/* Still need help */}
        <div className="mt-12 text-center bg-white rounded-xl p-8 shadow-sm border border-gray-100">
          <h3 className="text-xl font-semibold text-gray-900 mb-2">Still Have Questions?</h3>
          <p className="text-gray-600 mb-6">
            Can't find what you're looking for? We're here to help.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link
              to="/contact"
              className="px-8 py-3 bg-indigo-600 text-white rounded-xl font-semibold hover:bg-indigo-700 transition-colors"
            >
              Contact Us
            </Link>
            <Link
              to="/track-order"
              className="px-8 py-3 border border-gray-300 text-gray-700 rounded-xl font-semibold hover:bg-gray-50 transition-colors"
            >
              Track Your Order
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}
