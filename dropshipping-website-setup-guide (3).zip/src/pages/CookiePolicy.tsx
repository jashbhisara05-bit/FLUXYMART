import { Cookie } from 'lucide-react';

export default function CookiePolicy() {
  return (
    <div className="min-h-screen bg-gray-50">
      <section className="bg-gradient-to-br from-indigo-900 via-purple-900 to-slate-900 text-white py-16 sm:py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <Cookie className="w-12 h-12 text-indigo-300 mx-auto mb-4" />
          <h1 className="text-4xl sm:text-5xl font-bold mb-4">Cookie Policy</h1>
          <p className="text-xl text-gray-300">Last updated: January 1, 2026</p>
        </div>
      </section>

      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="bg-white rounded-xl shadow-sm p-6 sm:p-8">
          <h2 className="text-2xl font-bold text-gray-900 mb-4">What Are Cookies</h2>
          <p className="text-gray-600 leading-relaxed mb-6">
            Cookies are small text files that are placed on your computer or mobile device when you visit a website. They are widely used to make websites work more efficiently and provide information to the website owners. Cookies help us enhance your browsing experience by remembering your preferences and visits.
          </p>

          <h2 className="text-2xl font-bold text-gray-900 mb-4 mt-8">How We Use Cookies</h2>
          <p className="text-gray-600 leading-relaxed mb-4">We use cookies for the following purposes:</p>
          <ul className="list-disc pl-6 text-gray-600 space-y-2 mb-6">
            <li><strong>Essential Cookies:</strong> Required for the website to function properly. These enable core functionality such as security, network management, and shopping cart functionality.</li>
            <li><strong>Preference Cookies:</strong> Remember your settings and preferences to personalize your experience (e.g., language, currency).</li>
            <li><strong>Analytics Cookies:</strong> Help us understand how visitors interact with our website by collecting anonymous information. We use Google Analytics for this purpose.</li>
            <li><strong>Marketing Cookies:</strong> Track your browsing habits to deliver targeted advertisements that are relevant to you. We use Meta Pixel and Google Ads for retargeting.</li>
          </ul>

          <h2 className="text-2xl font-bold text-gray-900 mb-4 mt-8">Types of Cookies We Use</h2>
          <div className="overflow-x-auto mb-6">
            <table className="w-full text-sm">
              <thead>
                <tr className="bg-gray-50">
                  <th className="text-left px-4 py-3 font-semibold text-gray-900">Cookie Type</th>
                  <th className="text-left px-4 py-3 font-semibold text-gray-900">Duration</th>
                  <th className="text-left px-4 py-3 font-semibold text-gray-900">Purpose</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-100">
                <tr>
                  <td className="px-4 py-3 text-gray-700">Session Cookies</td>
                  <td className="px-4 py-3 text-gray-700">Session</td>
                  <td className="px-4 py-3 text-gray-700">Maintain shopping cart and login state</td>
                </tr>
                <tr>
                  <td className="px-4 py-3 text-gray-700">_ga, _gid (Google Analytics)</td>
                  <td className="px-4 py-3 text-gray-700">2 years / 24 hours</td>
                  <td className="px-4 py-3 text-gray-700">Analyze site traffic and user behavior</td>
                </tr>
                <tr>
                  <td className="px-4 py-3 text-gray-700">_fbp (Meta Pixel)</td>
                  <td className="px-4 py-3 text-gray-700">3 months</td>
                  <td className="px-4 py-3 text-gray-700">Deliver personalized ads on Facebook</td>
                </tr>
                <tr>
                  <td className="px-4 py-3 text-gray-700">Stripe Cookies</td>
                  <td className="px-4 py-3 text-gray-700">Session</td>
                  <td className="px-4 py-3 text-gray-700">Process payments securely</td>
                </tr>
              </tbody>
            </table>
          </div>

          <h2 className="text-2xl font-bold text-gray-900 mb-4 mt-8">Third-Party Cookies</h2>
          <p className="text-gray-600 leading-relaxed mb-6">
            In addition to our own cookies, we may also use various third-party cookies to report usage statistics, deliver advertisements, and improve the Service. These include:
          </p>
          <ul className="list-disc pl-6 text-gray-600 space-y-2 mb-6">
            <li><strong>Google Analytics:</strong> For website analytics and reporting</li>
            <li><strong>Meta (Facebook) Pixel:</strong> For retargeting and conversion tracking</li>
            <li><strong>Stripe:</strong> For secure payment processing</li>
            <li><strong>PayPal:</strong> For secure payment processing</li>
          </ul>

          <h2 className="text-2xl font-bold text-gray-900 mb-4 mt-8">Managing Cookies</h2>
          <p className="text-gray-600 leading-relaxed mb-4">
            Most web browsers allow you to control cookies through their settings. You can:
          </p>
          <ul className="list-disc pl-6 text-gray-600 space-y-2 mb-6">
            <li>Delete all cookies from your browser</li>
            <li>Block third-party cookies</li>
            <li>Block all cookies (this may affect website functionality)</li>
            <li>Set your browser to notify you when a cookie is being set</li>
          </ul>
          <p className="text-gray-600 leading-relaxed mb-6">
            Please note that blocking or deleting cookies may affect your experience on our website and limit access to certain features.
          </p>

          <h2 className="text-2xl font-bold text-gray-900 mb-4 mt-8">Your Consent</h2>
          <p className="text-gray-600 leading-relaxed mb-6">
            By continuing to use our website, you consent to the use of cookies as described in this policy. When you first visit our site, you will see a cookie consent banner that allows you to choose which cookies you accept.
          </p>

          <h2 className="text-2xl font-bold text-gray-900 mb-4 mt-8">Updates to This Policy</h2>
          <p className="text-gray-600 leading-relaxed mb-6">
            We may update this Cookie Policy from time to time. Changes will be posted on this page with an updated "Last updated" date. We encourage you to review this policy periodically.
          </p>

          <h2 className="text-2xl font-bold text-gray-900 mb-4 mt-8">Contact Us</h2>
          <p className="text-gray-600 leading-relaxed mb-6">
            If you have any questions about our use of cookies, please contact us at{' '}
            <a href="mailto:support@fluxymart.com" className="text-indigo-600 hover:underline">support@fluxymart.com</a>.
          </p>
        </div>
      </div>
    </div>
  );
}
