export interface ProductVariant {
  name: string;
  available: boolean;
}

export interface Product {
  id: number;
  name: string;
  slug: string;
  category: string;
  price: number;
  comparePrice: number | null;
  rating: number;
  reviewCount: number;
  description: string;
  features: string[];
  images: string[];
  colors: ProductVariant[];
  sizes: ProductVariant[];
  isBestSeller: boolean;
  isNew: boolean;
  badge?: string;
}

export const categories = [
  { id: 'all', name: 'All Products' },
  { id: 'home', name: 'Home & Living' },
  { id: 'tech', name: 'Tech & Gadgets' },
  { id: 'beauty', name: 'Beauty & Personal Care' },
  { id: 'fashion', name: 'Fashion & Accessories' },
  { id: 'kitchen', name: 'Kitchen & Dining' },
];

// Product catalog is currently empty. Add your products here.
export const products: Product[] = [];

export function getProductBySlug(slug: string): Product | undefined {
  return products.find(p => p.slug === slug);
}

export function getRelatedProducts(category: string, excludeId: number): Product[] {
  return products.filter(p => p.category === category && p.id !== excludeId).slice(0, 4);
}
