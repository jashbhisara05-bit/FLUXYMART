import { createContext, useContext, useReducer, ReactNode } from 'react';

export interface CartItem {
  id: number;
  productId: number;
  name: string;
  price: number;
  image: string;
  color?: string;
  size?: string;
  quantity: number;
}

interface CartState {
  items: CartItem[];
  discountCode: string | null;
  discountPercent: number;
}

type CartAction =
  | { type: 'ADD_TO_CART'; payload: CartItem }
  | { type: 'REMOVE_FROM_CART'; payload: { id: number } }
  | { type: 'UPDATE_QUANTITY'; payload: { id: number; quantity: number } }
  | { type: 'CLEAR_CART' }
  | { type: 'APPLY_DISCOUNT'; payload: { code: string; percent: number } }
  | { type: 'REMOVE_DISCOUNT' };

interface CartContextType {
  state: CartState;
  addToCart: (item: CartItem) => void;
  removeFromCart: (id: number) => void;
  updateQuantity: (id: number, quantity: number) => void;
  clearCart: () => void;
  applyDiscount: (code: string, percent: number) => void;
  removeDiscount: () => void;
  cartTotal: number;
  cartCount: number;
  shipping: number;
  discount: number;
  grandTotal: number;
}

const CartContext = createContext<CartContextType | undefined>(undefined);

function cartReducer(state: CartState, action: CartAction): CartState {
  switch (action.type) {
    case 'ADD_TO_CART': {
      const existingIndex = state.items.findIndex(
        item =>
          item.productId === action.payload.productId &&
          item.color === action.payload.color &&
          item.size === action.payload.size
      );
      if (existingIndex >= 0) {
        const newItems = [...state.items];
        newItems[existingIndex] = {
          ...newItems[existingIndex],
          quantity: newItems[existingIndex].quantity + action.payload.quantity,
        };
        return { ...state, items: newItems };
      }
      return { ...state, items: [...state.items, action.payload] };
    }
    case 'REMOVE_FROM_CART':
      return {
        ...state,
        items: state.items.filter(item => item.id !== action.payload.id),
      };
    case 'UPDATE_QUANTITY':
      return {
        ...state,
        items: state.items.map(item =>
          item.id === action.payload.id
            ? { ...item, quantity: action.payload.quantity }
            : item
        ),
      };
    case 'CLEAR_CART':
      return { ...state, items: [] };
    case 'APPLY_DISCOUNT':
      return { ...state, discountCode: action.payload.code, discountPercent: action.payload.percent };
    case 'REMOVE_DISCOUNT':
      return { ...state, discountCode: null, discountPercent: 0 };
    default:
      return state;
  }
}

export function CartProvider({ children }: { children: ReactNode }) {
  const [state, dispatch] = useReducer(cartReducer, {
    items: [],
    discountCode: null,
    discountPercent: 0,
  });

  const addToCart = (item: CartItem) =>
    dispatch({ type: 'ADD_TO_CART', payload: item });

  const removeFromCart = (id: number) =>
    dispatch({ type: 'REMOVE_FROM_CART', payload: { id } });

  const updateQuantity = (id: number, quantity: number) =>
    dispatch({ type: 'UPDATE_QUANTITY', payload: { id, quantity } });

  const clearCart = () => dispatch({ type: 'CLEAR_CART' });

  const applyDiscount = (code: string, percent: number) =>
    dispatch({ type: 'APPLY_DISCOUNT', payload: { code, percent } });

  const removeDiscount = () => dispatch({ type: 'REMOVE_DISCOUNT' });

  const subtotal = state.items.reduce(
    (sum, item) => sum + item.price * item.quantity,
    0
  );

  const discount = state.discountPercent
    ? subtotal * (state.discountPercent / 100)
    : 0;

  const shipping = 0; // Free delivery on all orders
  const cartTotal = subtotal;
  const cartCount = state.items.reduce((sum, item) => sum + item.quantity, 0);
  const grandTotal = Math.max(0, subtotal - discount + shipping);

  return (
    <CartContext.Provider
      value={{
        state,
        addToCart,
        removeFromCart,
        updateQuantity,
        clearCart,
        applyDiscount,
        removeDiscount,
        cartTotal,
        cartCount,
        shipping,
        discount,
        grandTotal,
      }}
    >
      {children}
    </CartContext.Provider>
  );
}

export function useCart() {
  const context = useContext(CartContext);
  if (!context) {
    throw new Error('useCart must be used within a CartProvider');
  }
  return context;
}
