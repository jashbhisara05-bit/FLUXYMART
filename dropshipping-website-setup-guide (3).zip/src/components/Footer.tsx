import { Link } from 'react-router-dom';
import { Package, Mail, Phone, MapPin, Heart } from 'lucide-react';

const footerLinks = {
  shop: {
    title: 'Shop',
    links: [
      { name: 'All Products', path: '/shop' },
      { name: 'Home & Living', path: '/shop?category=home' },
      { name: 'Tech & Gadgets', path: '/shop?category=tech' },
      { name: 'Beauty', path: '/shop?category=beauty' },
      { name: 'Fashion', path: '/shop?category=fashion' },
    ],
  },
  support: {
    title: 'Support',
    links: [
      { name: 'Contact Us', path: '/contact' },
      { name: 'FAQ', path: '/faq' },
      { name: 'Track Order', path: '/track-order' },
      { name: 'Shipping Info', path: '/shipping-policy' },
      { name: 'Returns & Exchanges', path: '/refund-policy' },
    ],
  },
  company: {
    title: 'Company',
    links: [
      { name: 'About Us', path: '/about' },
      { name: 'Privacy Policy', path: '/privacy-policy' },
      { name: 'Terms & Conditions', path: '/terms-conditions' },
      { name: 'Cookie Policy', path: '/cookie-policy' },
    ],
  },
};

const paymentMethods = [
  'Visa', 'Mastercard', 'PayPal', 'Stripe', 'Apple Pay', 'Google Pay'
];

export default function Footer() {
  return (
    <footer className="bg-gray-900 text-gray-300">
      {/* Main footer */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 lg:py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 lg:gap-12">
          {/* Brand column */}
          <div className="lg:col-span-1">
            <Link to="/" className="flex items-center space-x-2 mb-4">
              <div className="w-8 h-8 bg-gradient-to-br from-indigo-500 to-purple-600 rounded-lg flex items-center justify-center">
                <Package className="w-5 h-5 text-white" />
              </div>
              <span className="text-xl font-bold text-white">FluxyMart.com</span>
            </Link>
            <p className="text-sm text-gray-400 mb-6 leading-relaxed">
              Your trusted global dropshipping store. Premium products delivered to your doorstep with fast shipping and 24/7 support.
            </p>
            <div className="space-y-3 text-sm">
              <div className="flex items-center gap-3">
                <Mail className="w-4 h-4 text-indigo-400" />
                <span>support@fluxymart.com</span>
              </div>
              <div className="flex items-center gap-3">
                <Phone className="w-4 h-4 text-indigo-400" />
                <span>+1 (800) 123-4567</span>
              </div>
              <div className="flex items-center gap-3">
                <MapPin className="w-4 h-4 text-indigo-400" />
                <span>123 Commerce St, New York, NY 10001</span>
              </div>
            </div>
          </div>

          {/* Link columns */}
          {Object.values(footerLinks).map((section) => (
            <div key={section.title}>
              <h3 className="text-white font-semibold mb-4">{section.title}</h3>
              <ul className="space-y-2.5">
                {section.links.map((link) => (
                  <li key={link.name}>
                    <Link
                      to={link.path}
                      className="text-sm text-gray-400 hover:text-white transition-colors"
                    >
                      {link.name}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        {/* Trust badges */}
        <div className="mt-12 pt-8 border-t border-gray-800">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6 text-center">
            <div className="p-4 rounded-lg bg-gray-800/50">
              <div className="text-2xl mb-1">🔒</div>
              <p className="text-sm font-medium text-white">Secure Checkout</p>
              <p className="text-xs text-gray-400">SSL Encrypted</p>
            </div>
            <div className="p-4 rounded-lg bg-gray-800/50">
              <div className="text-2xl mb-1">🚚</div>
              <p className="text-sm font-medium text-white">Free Delivery</p>
              <p className="text-xs text-gray-400">On All Orders</p>
            </div>
            <div className="p-4 rounded-lg bg-gray-800/50">
              <div className="text-2xl mb-1">💯</div>
              <p className="text-sm font-medium text-white">30-Day Guarantee</p>
              <p className="text-xs text-gray-400">Money-Back Promise</p>
            </div>
            <div className="p-4 rounded-lg bg-gray-800/50">
              <div className="text-2xl mb-1">⭐</div>
              <p className="text-sm font-medium text-white">24/7 Support</p>
              <p className="text-xs text-gray-400">Live Chat & Email</p>
            </div>
          </div>
        </div>

        {/* Payment methods */}
        <div className="mt-8 pt-8 border-t border-gray-800">
          <p className="text-sm text-gray-400 text-center mb-4">We accept</p>
          <div className="flex flex-wrap justify-center gap-3">
            {paymentMethods.map((method) => (
              <span
                key={method}
                className="px-3 py-1.5 bg-gray-800 rounded text-xs text-gray-300 font-medium"
              >
                {method}
              </span>
            ))}
          </div>
        </div>
      </div>

      {/* Bottom bar */}
      <div className="border-t border-gray-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="flex flex-col md:flex-row items-center justify-between gap-4">
            <p className="text-sm text-gray-500">
              © {new Date().getFullYear()} FluxyMart.com. All rights reserved. Dropshipping Store.
            </p>
            <div className="flex items-center gap-4 text-sm text-gray-500">
              <Link to="/privacy-policy" className="hover:text-gray-300 transition-colors">Privacy</Link>
              <Link to="/terms-conditions" className="hover:text-gray-300 transition-colors">Terms</Link>
              <Link to="/cookie-policy" className="hover:text-gray-300 transition-colors">Cookies</Link>
            </div>
            <p className="text-sm text-gray-600 flex items-center gap-1">
              Made with <Heart className="w-3.5 h-3.5 text-red-400 fill-red-400" /> for dropshipping
            </p>
          </div>
        </div>
      </div>
    </footer>
  );
}
